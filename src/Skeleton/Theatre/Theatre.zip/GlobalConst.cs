﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Theatre
{
    public class GlobalConst
    {
        public string dbConnectionStringDobri = "Server=.;Database=VaporStore;User Id=sa;Password=DobriSoftUni2021;";
    }
}
